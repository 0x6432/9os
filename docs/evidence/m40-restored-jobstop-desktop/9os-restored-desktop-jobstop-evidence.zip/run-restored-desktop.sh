#!/bin/bash
set -euo pipefail
export PATH=/data/tools/bin:$PATH
cd /data/9os
make -j2 ARCH=x86_64 USERLAND=alpine iso >/data/restored-alpine-kernel-build.log 2>&1
scripts/alpine-desktop-tests.sh x86_64 >/data/restored-desktop.out 2>&1
