from pathlib import Path
import shutil,subprocess,gzip
T=Path('/data/9os');S=T/'userland/alpine-root-x86_64';R=Path('/data/desktop-failure-phase-root')
if R.exists():raise SystemExit('refuse existing diagnostic root')
subprocess.run(['cp','-al',str(T/'userland/alpine-desktop-root-x86_64'),str(R)],check=True)
for n in ['desktopa11y','desktopframecheck','inputeventcapture','qt-key-observer-caller']:
 p=R/'usr/bin'/n;p.unlink(missing_ok=True);shutil.copy2(S/'usr/bin'/n,p)
for rel in ['usr/lib/lib9os-qt-key-observer.so','usr/lib/9os-tests/libqt-key-observer-mock.so']:
 p=R/rel;p.parent.mkdir(parents=True,exist_ok=True);p.unlink(missing_ok=True);shutil.copy2(S/rel,p)
p=R/'usr/bin/alpine-plasma-probe';old=p.read_text()
marker='  # Genuine failure pixels only, taken AFTER failure is irrevocable and before\n'
diag='''  # PRIVATE failure-only diagnostic. The original readiness result above is\n  # already frozen and this path exits 1 unconditionally; never rescue a gate.\n  echo KONSOLE_FAILURE_ONLY_A11Y_TRACE_BEGIN\n  if timeout -k 2 -s TERM 8 desktopa11y --terminal-trace "$client" > "$D/failure-a11y-phase.log" 2>&1;then phase_rc=0;else phase_rc=$?;fi\n  cat "$D/failure-a11y-phase.log"\n  echo "KONSOLE_FAILURE_ONLY_A11Y_TRACE_END rc=$phase_rc"\n  echo KONSOLE_FAILURE_ONLY_A11Y_SYSCALL_BEGIN\n  if timeout -k 2 -s TERM 8 strace -f -tt -T -o "$D/failure-a11y-syscalls.log" desktopa11y --terminal-trace "$client" > "$D/failure-a11y-phase2.log" 2>&1;then phase_rc=0;else phase_rc=$?;fi\n  cat "$D/failure-a11y-phase2.log"\n  tail -n 100 "$D/failure-a11y-syscalls.log" 2>/dev/null || true\n  echo "KONSOLE_FAILURE_ONLY_A11Y_SYSCALL_END rc=$phase_rc"\n'''
assert old.count(marker)==1
p.unlink();p.write_text(old.replace(marker,diag+marker));p.chmod(0o755)
Path('/data/failure-phase-probe.patch').write_text(subprocess.check_output(['diff','-u',str(T/'userland/alpine/desktop-overlay/usr/bin/alpine-plasma-probe'),str(p)],text=True)if False else diag)
for sample in ['linux1','guest1','guest2']:
 s=Path('/data/recovered-development/hardware-capture-integrated-observer-'+sample+'.sh').read_text().replace('integrated-observer-'+sample,'failure-phase-'+sample).replace('/data/desktop-qt-observer-integrated-root',str(R)).replace('/data/desktop-qt-observer-integrated.img','/data/desktop-failure-phase.img')
 p=Path('/data/hardware-capture-failure-phase-'+sample+'.sh');p.write_text(s);p.chmod(0o755)
# The same signed Linux kernel/resources/modules as the earlier matched control.
w=Path('/data/linux-tcg-desktop');r=w/'initramfs';r.mkdir(parents=True,exist_ok=True)
for d in ['bin','lib','dev','proc','sys','tmp','rootfs','modules']:(r/d).mkdir(exist_ok=True)
shutil.copy2(S/'bin/busybox',r/'bin/busybox');(r/'bin/busybox').chmod(0o755)
shutil.copy2((S/'lib/ld-musl-x86_64.so.1').resolve(),r/'lib/ld-musl-x86_64.so.1')
for n in ['sh','mount','insmod','poweroff','sleep','mkdir','chmod','chown','ln','rm','cp','chroot']:(r/'bin'/n).symlink_to('busybox')
m=Path('/data/linux-input-oracle/root/lib/modules/6.12.113-0-virt')
deps={a:b.split()for a,b in(line.split(':')for line in(m/'modules.dep').read_text().splitlines())};order=[]
def add(p):
 if p in order:return
 for d in deps[p]:add(d)
 order.append(p)
for n in ['virtio_blk','ext2','evdev','virtio_input','bochs']:add(next(p for p in deps if p.endswith('/'+n+'.ko.gz')))
for i,p in enumerate(order):(r/'modules'/f'{i}.ko').write_bytes(gzip.decompress((m/p).read_bytes()))
(r/'load-modules').write_text('\n'.join('insmod /modules/%d.ko'%i for i in range(len(order)))+'\n')
(w/'physical-modules.txt').write_text('\n'.join(order)+'\n')
(r/'init').write_text('''#!/bin/sh
export PATH=/bin
mount -t proc proc /proc
mount -t sysfs sysfs /sys
mount -t devtmpfs devtmpfs /dev
. /load-modules
for i in 1 2 3 4 5;do [ ! -b /dev/vda1 ] || break;sleep 1;done
if ! mount -t ext2 -o rw /dev/vda1 /rootfs;then echo LINUX_TCG_FIXTURE_MOUNT_FAILED;poweroff -f;fi
mount -t proc proc /rootfs/proc
mount -t sysfs sysfs /rootfs/sys
mount -t devtmpfs devtmpfs /rootfs/dev
mkdir -p /rootfs/dev/pts /rootfs/dev/shm
mount -t devpts -o newinstance,ptmxmode=0666,mode=0620 devpts /rootfs/dev/pts
rm -f /rootfs/dev/ptmx
ln -s pts/ptmx /rootfs/dev/ptmx
mount -t tmpfs -o mode=1777 tmpfs /rootfs/dev/shm
mount -t tmpfs -o mode=1777 tmpfs /rootfs/tmp
mount -t tmpfs -o mode=755 tmpfs /rootfs/run
mount -t tmpfs -o mode=755 tmpfs /rootfs/home
mkdir -p /rootfs/home/user
chown 1000:1000 /rootfs/home/user
chmod 700 /rootfs/home/user
echo LINUX_PHYSICAL_ORACLE_KERNEL=Linux
exec chroot /rootfs /bin/sh -c 'printf "LINUX_PHYSICAL_ORACLE_KERNEL=%s\\n" "$(uname -s)"; exec /sbin/init'
''');(r/'init').chmod(0o755)
subprocess.run('find . -print0 | cpio -0 -o -H newc --owner=0:0 --quiet | gzip -1 > /data/linux-tcg-desktop/physical-initramfs.cpio.gz',cwd=r,shell=True,check=True)
(w/'bin').mkdir(exist_ok=True)
(w/'bin/make').write_text('''#!/usr/bin/env python3
import os,sys,shlex
args={a.split('=',1)[0]:a.split('=',1)[1]for a in sys.argv[1:]if '='in a}
if 'run' not in sys.argv or args.get('ARCH')!='x86_64':sys.exit('Linux adapter refuses builds or non-x86 targets')
q=['/data/tools/bin/qemu-system-x86_64','-M','q35','-cpu','qemu64,+smep,+smap,+rdrand','-smp',args['SMP'],'-m',args['QEMU_MEMORY'],'-kernel','/data/linux-input-oracle/root/boot/vmlinuz-virt','-initrd','/data/linux-tcg-desktop/physical-initramfs.cpio.gz','-append','console=ttyS0 panic=-1 rdinit=/init','-snapshot','-device','virtio-keyboard-pci','-device','virtio-tablet-pci','-serial','stdio','-no-reboot']+shlex.split(args['QEMUFLAGS'])
os.execv(q[0],q)
''');(w/'bin/make').chmod(0o755)
print('Prepared frozen current-head diagnostic fixture; original readiness/gates/taps unchanged; diagnostics only after irrevocable failure',flush=True)
