from pathlib import Path
import zipfile,sys,json,subprocess,re
sample=sys.argv[1];top=Path('/data/9os');s=(Path('/data')/f'hardware-capture-failure-phase-{sample}.out').read_text(errors='replace')
records=[l for l in s.splitlines()if l.startswith(('KONSOLE_READINESS ','INPUT_CAPTURE_DONE ','KONSOLE_FAILURE_ONLY_A11Y_TRACE_END ','KONSOLE_FAILURE_ONLY_A11Y_SYSCALL_END '))or re.fullmatch(r'\d+/\d+ passed',l)]
print('\n'.join(records),flush=True)
files=set(top.joinpath('build').glob(f'test-hardware-capture-failure-phase-{sample}-x86_64*'))
for pat in ['failure-phase-*','prepare-failure-phase.*','run-failure-phase.sh','archive-failure-phase.py','no-active-9os-vm.py','check-restored-outer.py',f'hardware-capture-failure-phase-{sample}*']:files.update(Path('/data').glob(pat))
files.update(top.joinpath('scripts').glob('*observer*.py'));files.update(top.joinpath('userland/tests/qt-key-observer').glob('*'))
files.update([top/'userland/tests/desktopa11y.c',Path('/data/desktop-failure-phase-root/usr/bin/alpine-plasma-probe'),Path('/data/linux-tcg-desktop/bin/make'),Path('/data/linux-tcg-desktop/initramfs/init'),Path('/data/linux-tcg-desktop/physical-modules.txt')])
out=Path('/data')/f'9os-failure-phase-{sample}-evidence.zip'
with zipfile.ZipFile(out,'w',zipfile.ZIP_DEFLATED)as z:
 for p in sorted(files):
  if p.is_file():z.write(p,str(p.relative_to('/data')))
print('EVIDENCE_READY',out.name,out.stat().st_size,flush=True)
