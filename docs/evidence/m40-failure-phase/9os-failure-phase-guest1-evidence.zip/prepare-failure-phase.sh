#!/bin/bash
set -euo pipefail
umask 022
export PATH=/data/tools/bin:$PATH
cd /data/9os
make -s -j2 ARCH=x86_64 USERLAND=alpine CMDLINE=root=/dev/vda1 iso > /data/failure-phase-build.log 2>&1
S=/data/9os/userland/alpine-desktop-root-x86_64
mkdir -p /data/linux-input-oracle/root
B=/data/9os/userland/alpine-root-x86_64
"$B/lib/ld-musl-x86_64.so.1" --library-path "$B/lib:$B/usr/lib" "$B/sbin/apk" --arch x86_64 --root /data/linux-input-oracle/root --initdb --no-scripts --no-chown --no-cache --keys-dir "$B/etc/apk/keys" --repository https://dl-cdn.alpinelinux.org/alpine/v3.22/main add linux-virt=6.12.113-r0 > /data/linux-kernel-packages.log 2>&1
python3 /data/prepare-failure-phase.py
scripts/mkdisk.sh /data/desktop-failure-phase.img 3584 /data/desktop-failure-phase-root
sha256sum /data/desktop-failure-phase.img /data/desktop-failure-phase-root/usr/bin/{alpine-plasma-probe,desktopa11y,konsole-key-trace,inputeventcapture,qt-key-observer-caller} /data/desktop-failure-phase-root/usr/lib/{lib9os-qt-key-observer.so,9os-tests/libqt-key-observer-mock.so} /data/hardware-capture-failure-phase-{linux1,guest1,guest2}.sh /data/9os/scripts/{qemu-type.py,qemu-ready-type.py,qemu-test.py,qt-key-observer-check.py,input-capture-check.py} /data/9os/build/x86_64-alpine/{kernel.elf,9os.iso,initramfs.cpio,limine.conf} /data/linux-tcg-desktop/bin/make /data/linux-tcg-desktop/physical-initramfs.cpio.gz /data/linux-input-oracle/root/boot/vmlinuz-virt > /data/failure-phase-fixtures.sha256
printf 'FAILURE_PHASE_FIXTURES_READY\n'
