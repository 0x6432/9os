from pathlib import Path
import zipfile,sys,re
D=Path('/data');sample=sys.argv[1]
files=set((D/'9os/build').glob(f'test-hardware-capture-bulk-candidate-{sample}-x86_64*'))
for pat in ['bulk-candidate-*','prepare-bulk-candidate.py','run-bulk-candidate.sh','archive-bulk-candidate.py',f'hardware-capture-bulk-candidate-{sample}*']:
 files.update(D.glob(pat))
files.update((D/'desktop-bulk-candidate-root'/p)for p in ['usr/bin/desktopa11y-dbus','usr/bin/alpine-plasma-probe'])
out=D/f'9os-bulk-candidate-{sample}-evidence.zip'
with zipfile.ZipFile(out,'w',zipfile.ZIP_DEFLATED)as z:
 for p in sorted(files):
  if p.is_file():z.write(p,str(p.relative_to(D)))
s=(D/f'hardware-capture-bulk-candidate-{sample}.out').read_text(errors='replace')
for l in s.splitlines():
 if l.startswith(('KONSOLE_READINESS ','KONSOLE_READINESS_BACKEND=','terminal-dbus: ','DBUS_A11Y_TERMINAL ','FAIL   '))or re.fullmatch(r'\d+/\d+ passed',l):print(l[:700])
print('CANDIDATE_EVIDENCE_READY',out.name,out.stat().st_size,flush=True)
