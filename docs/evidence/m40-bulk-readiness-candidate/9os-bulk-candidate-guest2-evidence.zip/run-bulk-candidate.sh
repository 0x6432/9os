#!/bin/bash
set -euo pipefail
export PATH=/data/frozen-x86-run/bin:/data/tools/bin:$PATH
cd /data/9os
python3 /data/prepare-bulk-candidate.py
scripts/mkdisk.sh /data/desktop-bulk-candidate.img 3584 /data/desktop-bulk-candidate-root >/data/bulk-candidate-mkdisk.log 2>&1
sha256sum /data/desktop-bulk-candidate.img /data/desktop-bulk-candidate-root/usr/bin/{desktopa11y-dbus,alpine-plasma-probe} /data/hardware-capture-bulk-candidate-{linux1,guest1,guest2}.sh build/x86_64-alpine/{9os.iso,kernel.elf,initramfs.cpio} /data/frozen-x86-run/bin/make /data/linux-tcg-desktop/bin/make /data/linux-tcg-desktop/physical-initramfs.cpio.gz /data/linux-input-oracle/root/boot/vmlinuz-virt >/data/bulk-candidate-fixtures.sha256
for sample in linux1 guest1 guest2;do
 python3 /data/no-active-9os-vm.py
 sha256sum -c /data/bulk-candidate-fixtures.sha256 >/dev/null
 echo "CANDIDATE_START $sample $(date -u +%FT%TZ)"
 set +e
 if [ "$sample" = linux1 ];then PATH=/data/linux-tcg-desktop/bin:$PATH /data/hardware-capture-bulk-candidate-$sample.sh x86_64 >/data/hardware-capture-bulk-candidate-$sample.out 2>&1
 else /data/hardware-capture-bulk-candidate-$sample.sh x86_64 >/data/hardware-capture-bulk-candidate-$sample.out 2>&1;fi
 rc=$?;set -e
 echo "CANDIDATE_END $sample rc=$rc $(date -u +%FT%TZ)"
 python3 /data/no-active-9os-vm.py
 sha256sum -c /data/bulk-candidate-fixtures.sha256 >/dev/null
 set +e
 python3 scripts/input-capture-check.py build/test-hardware-capture-bulk-candidate-$sample-x86_64.log >/data/hardware-capture-bulk-candidate-$sample-raw-check.out 2>&1
 raw=$?;set -e
 echo "CANDIDATE_RAW $sample rc=$raw";cat /data/hardware-capture-bulk-candidate-$sample-raw-check.out
 python3 /data/archive-bulk-candidate.py "$sample"
 if [ "$sample" = linux1 ];then
  [ "$raw" = 0 ] || { echo 'STOP invalid Linux control';exit 2; }
  python3 - <<'PY'
from pathlib import Path
import re
s=Path('/data/hardware-capture-bulk-candidate-linux1.out').read_text(errors='replace')
assert re.findall(r'^\d+/\d+ passed$',s,re.M)==['17/18 passed']
assert re.findall(r'^FAIL   .*$',s,re.M)==['FAIL   grep -q "^violations 0" /proc/lockdep']
assert 'DBUS_A11Y_TERMINAL focused=1 showing=1 visible=1' in s
assert 'KONSOLE_READINESS_BACKEND=candidate-live-dbus' in s
assert 'QT_KEY_TRACE_LOADED' not in s and 'WAYLAND_KEY_TRACE ' not in s
PY
 fi
done
