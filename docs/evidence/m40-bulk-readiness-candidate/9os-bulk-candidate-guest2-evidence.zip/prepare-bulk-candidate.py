from pathlib import Path
import subprocess,shutil
D=Path('/data');R=D/'desktop-bulk-candidate-root'
subprocess.run(['python3',str(D/'no-active-9os-vm.py')],check=True)
if R.exists():raise SystemExit('refuse existing fixture')
subprocess.run(['cp','-al',str(D/'desktop-bulk-integrated-root'),str(R)],check=True)
p=R/'usr/bin/alpine-plasma-probe';s=p.read_text()
old='timeout -k 2 -s TERM 8 desktopa11y --terminal "$client"'
assert s.count(old)==1
s=s.replace(old,'timeout -k 2 -s TERM 8 desktopa11y-dbus "$client"')
anchor=' pty_ready=0;terminal_ready=0;deadline=$(( $(date +%s) + 120 ))'
assert s.count(anchor)==1
s=s.replace(anchor,' echo KONSOLE_READINESS_BACKEND=candidate-live-dbus\n'+anchor)
p.unlink();p.write_text(s);p.chmod(0o755)
for sample in ['linux1','guest1','guest2']:
 s=(D/('hardware-capture-bulk-a11y-'+sample+'.sh')).read_text()
 s=s.replace('bulk-a11y-'+sample,'bulk-candidate-'+sample).replace('/data/desktop-bulk-a11y-root',str(R)).replace('/data/desktop-bulk-a11y.img','/data/desktop-bulk-candidate.img')
 s=s.replace('ALPINE_PLASMA_KEY_TRACE=1 ALPINE_QT_KEY_TRACE=1 ALPINE_A11Y_DBUS_POST_READY_DIAGNOSTIC=1 ','')
 p=D/('hardware-capture-bulk-candidate-'+sample+'.sh');p.write_text(s);p.chmod(0o755)
 subprocess.run(['sh','-n',str(p)],check=True)
print('PRIVATE_CANDIDATE_PREPARED: backend selected BEFORE attempt, no fallback/rescue, same PID role/state/deadline; no Qt/Wayland observers',flush=True)
