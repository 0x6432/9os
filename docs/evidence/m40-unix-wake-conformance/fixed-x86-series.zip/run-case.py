from pathlib import Path
import os,json,hashlib,subprocess,time
T=Path('/data/9os');D=Path(os.environ['CASE_DIR']);result=D/'result.json'
assert not result.exists(),'No retry or overwrite of baseline'
for p in Path('/proc').iterdir():
 if not p.name.isdigit():continue
 try:a=(p/'cmdline').read_bytes().split(b'\0')
 except OSError:continue
 assert not any(x.rsplit(b'/',1)[-1].startswith(b'qemu-system-')and b' 'not in x for x in a),'Existing VM; do not overlap'
allowed=sorted(os.sched_getaffinity(0));assert len(allowed)>=2;os.sched_setaffinity(0,allowed[:2])
files=[T/'build/x86_64'/n for n in ['kernel.elf','9os.iso','initramfs.cpio']]+[T/'userland/root-x86_64/bin/pollwakebench-study',Path('/data/9os-unix-wake-study/userland/tests/pollwakebench.c'),T/'scripts/qemu-test.py',Path('/data/unix-wake-conformance/adapter/make'),T/'userland/root-x86_64/bin/unixpolltest',Path('/data/9os-unix-wake-study/userland/tests/unixpolltest.c')]
def hashes():return{str(p):hashlib.sha256(p.read_bytes()).hexdigest()for p in files}
commands=['pollwakebench-study','pollwakebench-study --inotify','pollwakebench-study --unix','pollwakebench-study --unix-inotify','su user -s /bin/sh -c "pollwakebench-study --unix"','su user -s /bin/sh -c "pollwakebench-study --unix-inotify"',"grep -q '^violations 0' /proc/lockdep"]
commands=commands[:-1]+['unixpolltest','su user -s /bin/sh -c unixpolltest','pollfiltertest','socktest','ipctest','polltest','su user -s /bin/sh -c pollfiltertest','su user -s /bin/sh -c socktest','su user -s /bin/sh -c ipctest','su user -s /bin/sh -c polltest']+commands[-1:]
r={'accepted':False,'before':hashes(),'commands':commands,'kernel_base':'3a90eed','benchmark_wip':'c63d67a','host_available_cpus':allowed,'host_selected_cpus':allowed[:2],'guest':'SMP'+os.environ['CASE_SMP']+'/512M core-only, NOT full desktop','started':time.time()};result.write_text(json.dumps(r,indent=2)+'\n')
env={**os.environ,'PATH':'/data/unix-wake-conformance/adapter'+':/data/tools/bin:'+os.environ['PATH']}
with(D/'driver.out').open('w')as f:r['driver_rc']=subprocess.run(['python3','scripts/qemu-test.py','x86_64','--memory','512M','--smp',os.environ['CASE_SMP'],'--boot-timeout','120','--timeout','60','--log',str(D/'guest.log'),*commands],cwd=T,env=env,stdout=f,stderr=subprocess.STDOUT).returncode
r['after']=hashes();r['fixture_intact']=r['before']==r['after'];r['accepted']=r['driver_rc']==0 and r['fixture_intact'];r['finished']=time.time();result.write_text(json.dumps(r,indent=2)+'\n');print({k:r[k]for k in ['accepted','driver_rc','fixture_intact']})
