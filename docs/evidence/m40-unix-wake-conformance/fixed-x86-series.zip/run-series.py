from pathlib import Path
import subprocess,os,json
D=Path('/data/unix-wake-conformance'); out=D/'series.json'
assert not out.exists(),'No retry'
r={'plan':[1,4,8],'results':[],'accepted':False};out.write_text(json.dumps(r,indent=2))
for n in r['plan']:
 d=D/f'smp{n}';d.mkdir()
 with (d/'controller.out').open('w') as f:
  rc=subprocess.run(['python3',str(D/'run-case.py')],env={**os.environ,'CASE_DIR':str(d),'CASE_SMP':str(n)},stdout=f,stderr=subprocess.STDOUT).returncode
 result=json.loads((d/'result.json').read_text()) if (d/'result.json').exists() else {}
 r['results'].append({'smp':n,'controller_rc':rc,'accepted':result.get('accepted',False)});out.write_text(json.dumps(r,indent=2))
 if rc or not result.get('accepted'):break
r['accepted']=len(r['results'])==3 and all(x['accepted']for x in r['results']);out.write_text(json.dumps(r,indent=2));print(json.dumps(r))
