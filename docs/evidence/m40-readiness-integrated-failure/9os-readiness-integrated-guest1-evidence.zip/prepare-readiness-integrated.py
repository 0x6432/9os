from pathlib import Path
import subprocess,shutil
D=Path('/data');T=D/'9os';R=D/'desktop-readiness-integrated-root'
subprocess.run(['python3',str(D/'no-active-9os-vm.py')],check=True)
if R.exists():raise SystemExit('refuse existing fixture')
subprocess.run(['cp','-al',str(D/'desktop-bulk-candidate-root'),str(R)],check=True)
p=R/'usr/bin/alpine-plasma-probe';p.unlink();shutil.copy2(T/'userland/alpine/desktop-overlay/usr/bin/alpine-plasma-probe',p);p.chmod(0o755)
s=(D/'hardware-capture-bulk-candidate-guest1.sh').read_text().replace('bulk-candidate-guest1','readiness-integrated-guest1').replace('/data/desktop-bulk-candidate-root',str(R)).replace('/data/desktop-bulk-candidate.img','/data/desktop-readiness-integrated.img')
anchor='ALPINE_PLASMA_OUTPUT=kms ';assert s.count(anchor)==1
s=s.replace(anchor,'ALPINE_TERMINAL_QUERY=live-dbus '+anchor)
p=D/'hardware-capture-readiness-integrated-guest1.sh';p.write_text(s);p.chmod(0o755)
subprocess.run(['sh','-n',str(p)],check=True)
(D/'readiness-integrated-source-head.txt').write_text(subprocess.check_output(['git','rev-parse','HEAD'],cwd=T,text=True))
print('READINESS_INTEGRATED_FIXTURE_PREPARED checked-in selector; no Qt/Wayland observers',flush=True)
