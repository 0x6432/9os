#!/bin/bash
set -euo pipefail
export PATH=/data/frozen-x86-run/bin:/data/tools/bin:$PATH
cd /data/9os
python3 /data/prepare-readiness-integrated.py
scripts/mkdisk.sh /data/desktop-readiness-integrated.img 3584 /data/desktop-readiness-integrated-root >/data/readiness-integrated-mkdisk.log 2>&1
sha256sum /data/desktop-readiness-integrated.img /data/desktop-readiness-integrated-root/usr/bin/{desktopa11y-dbus,alpine-plasma-probe} /data/hardware-capture-readiness-integrated-guest1.sh build/x86_64-alpine/{9os.iso,kernel.elf,initramfs.cpio} /data/frozen-x86-run/bin/make /data/readiness-integrated-source-head.txt >/data/readiness-integrated-fixtures.sha256
python3 /data/no-active-9os-vm.py
sha256sum -c /data/readiness-integrated-fixtures.sha256 >/dev/null
echo "READINESS_INTEGRATED_START $(date -u +%FT%TZ)"
set +e
/data/hardware-capture-readiness-integrated-guest1.sh x86_64 >/data/hardware-capture-readiness-integrated-guest1.out 2>&1
rc=$?;set -e
echo "READINESS_INTEGRATED_END rc=$rc $(date -u +%FT%TZ)"
python3 /data/no-active-9os-vm.py
sha256sum -c /data/readiness-integrated-fixtures.sha256 >/dev/null
set +e
python3 scripts/input-capture-check.py build/test-hardware-capture-readiness-integrated-guest1-x86_64.log >/data/hardware-capture-readiness-integrated-guest1-raw-check.out 2>&1
raw=$?;set -e
echo "READINESS_INTEGRATED_RAW rc=$raw";cat /data/hardware-capture-readiness-integrated-guest1-raw-check.out
python3 /data/archive-readiness-integrated.py
