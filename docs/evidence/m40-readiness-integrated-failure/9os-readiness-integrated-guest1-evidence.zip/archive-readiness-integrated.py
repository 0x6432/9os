from pathlib import Path
import zipfile,re
D=Path('/data');files=set((D/'9os/build').glob('test-hardware-capture-readiness-integrated-guest1-x86_64*'))
for pat in ['readiness-integrated-*','hardware-capture-readiness-integrated-guest1*','prepare-readiness-integrated.py','run-readiness-integrated.sh','archive-readiness-integrated.py']:
 files.update(D.glob(pat))
files.add(D/'frozen-x86-run/bin/make')
files.update((D/'desktop-readiness-integrated-root'/p)for p in ['usr/bin/alpine-plasma-probe','usr/bin/desktopa11y-dbus'])
out=D/'9os-readiness-integrated-guest1-evidence.zip'
with zipfile.ZipFile(out,'w',zipfile.ZIP_DEFLATED)as z:
 for p in sorted(files):
  if p.is_file():z.write(p,str(p.relative_to(D)))
s=(D/'hardware-capture-readiness-integrated-guest1.out').read_text(errors='replace')
for l in s.splitlines():
 if l.startswith(('KONSOLE_READINESS ','KONSOLE_READINESS_BACKEND=','DBUS_A11Y_TERMINAL ','terminal-dbus: ','FAIL   '))or re.fullmatch(r'\d+/\d+ passed',l):print(l[:700])
print('READINESS_INTEGRATED_EVIDENCE_READY',out.name,out.stat().st_size,flush=True)
