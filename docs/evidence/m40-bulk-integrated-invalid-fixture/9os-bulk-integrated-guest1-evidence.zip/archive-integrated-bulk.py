from pathlib import Path
import zipfile,re,json,hashlib,subprocess,os
from importlib.machinery import SourceFileLoader
D=Path('/data');T=D/'9os';W=D/'9os-failure-phase-evidence'
subprocess.run(['python3',str(D/'no-active-9os-vm.py')],check=True)
check=subprocess.run(['sha256sum','-c',str(D/'bulk-integrated-fixtures.sha256')],cwd=T,text=True,capture_output=True)
(D/'bulk-integrated-post-hash-check.txt').write_text(check.stdout+check.stderr)
assert check.returncode==1
assert [l for l in check.stdout.splitlines()if l.endswith(': FAILED')]==['build/x86_64-alpine/9os.iso: FAILED','build/x86_64-alpine/initramfs.cpio: FAILED']
files=set(T.glob('build/test-hardware-capture-bulk-integrated-guest1-x86_64*'))
for pattern in ['bulk-integrated-*','hardware-capture-bulk-integrated-guest1*','prepare-bulk-integrated.py','run-bulk-integrated.sh','archive-integrated-bulk.py']:
 files.update(D.glob(pattern))
files.update((D/'desktop-bulk-integrated-root'/p)for p in ['usr/bin/alpine-plasma-probe','usr/bin/desktopa11y-dbus'])
files.update(p for folder in ['tests/a11y-dbus-host','userland/tests/a11y-dbus']for p in(T/folder).glob('*')if p.is_file())
archive=D/'9os-bulk-integrated-guest1-evidence.zip';g=SourceFileLoader('gh','/tmp/9os-gh.py').load_module()
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED)as z:
 for p in sorted(files):
  if not p.is_file():continue
  b=p.read_bytes()
  if g.TOKEN.encode()in b or re.search(rb'ghp_[A-Za-z0-9]{25,}',b):raise SystemExit('Credential scan rejected evidence')
  z.writestr(str(p.relative_to(D)),b)
s=(D/'hardware-capture-bulk-integrated-guest1.out').read_text(errors='replace')
r={'fixture_integrity_valid':False,'runtime_head':'c24a22bae026b66f29906ba564ea656951aa474a','summary':re.findall(r'^\d+/\d+ passed$',s,re.M),'failures':[l for l in s.splitlines()if l.startswith('FAIL   ')],'observations':re.findall(r'^terminal-dbus: .*$',s,re.M),'archive_sha256':hashlib.sha256(archive.read_bytes()).hexdigest()}
out=W/'docs/evidence/m40-bulk-integrated-invalid-fixture';out.mkdir(parents=True,exist_ok=False)
(out/archive.name).write_bytes(archive.read_bytes());(out/'results.json').write_text(json.dumps(r,indent=2)+'\n')
(out/'README.md').write_text('# INVALID frozen-fixture trial: checked-in PR33 integrated diagnostic\n\nThe observed runtime log reports 18/18, but DO NOT accept this as a controlled\nfrozen-fixture trial. The driver invoked make run, which automatically rebuilt\ninitramfs.cpio and 9os.iso immediately before starting QEMU because the base\nroot had acquired the new tiny helper. Kernel ELF, disk, driver, probe and helper\nhashes remained unchanged; the two boot-artifact mismatches are retained in\nbulk-integrated-post-hash-check.txt alongside the ORIGINAL expected manifest.\nThe end-of-run hash gate correctly stopped the controller before acceptance.\nDo not replace that original manifest with the new hashes or hide this failure.\n\nSubsequent frozen runs use a separate x86-only make adapter that marks the\nexisting ISO and firmware old; dry-run proves exactly one QEMU invocation and\nzero build commands. This is a harness fix, not a kernel/runtime cure.\n\nObserved original libatspi gate and explicit post-ready bulk query succeeded,\nwith real Qt PID769; raw390/262edges/128taps, outer262, Qt262/0autorepeat. Those\nlayer observations do not repair failed fixture integrity or prove reliability.\nAll raw evidence/checkers/scripts/PNG files retained. No retry of this sample is\nsilently substituted. M40 and earlier failure/integration holds remain open.\nEvidence-only branch; do not merge binary archives into product code.\n')
subprocess.run(['git','add','docs/evidence/m40-bulk-integrated-invalid-fixture'],cwd=W,check=True)
subprocess.run(['git','-c','user.name=0x6432','-c','user.email=0x6432@users.noreply.github.com','commit','-m','Retain invalid integrated trial and explicit boot-artifact hash failure'],cwd=W,check=True)
os.chdir(W);g.push('notion/m40-failure-phase-evidence');print(json.dumps(r),flush=True)
