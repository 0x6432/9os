#!/bin/bash
set -euo pipefail
export PATH=/data/tools/bin:$PATH
cd /data/9os
python3 /data/prepare-bulk-integrated.py
scripts/mkdisk.sh /data/desktop-bulk-integrated.img 3584 /data/desktop-bulk-integrated-root >/data/bulk-integrated-mkdisk.log 2>&1
sha256sum /data/desktop-bulk-integrated.img /data/desktop-bulk-integrated-root/usr/bin/{desktopa11y-dbus,alpine-plasma-probe} /data/hardware-capture-bulk-integrated-guest1.sh build/x86_64-alpine/{9os.iso,kernel.elf,initramfs.cpio} > /data/bulk-integrated-fixtures.sha256
python3 /data/no-active-9os-vm.py
sha256sum -c /data/bulk-integrated-fixtures.sha256 >/dev/null
echo "INTEGRATED_START $(date -u +%FT%TZ)"
set +e
/data/hardware-capture-bulk-integrated-guest1.sh x86_64 >/data/hardware-capture-bulk-integrated-guest1.out 2>&1
rc=$?
set -e
echo "INTEGRATED_END rc=$rc $(date -u +%FT%TZ)"
python3 /data/no-active-9os-vm.py
sha256sum -c /data/bulk-integrated-fixtures.sha256 >/dev/null
for check in raw outer qt;do
 case "$check" in raw) script=scripts/input-capture-check.py;;outer) script=/data/check-restored-outer.py;;qt) script=scripts/qt-key-observer-check.py;;esac
 set +e
 python3 "$script" $([ "$check" != qt ] || echo --require-no-autorepeat) build/test-hardware-capture-bulk-integrated-guest1-x86_64.log >/data/hardware-capture-bulk-integrated-guest1-$check-check.out 2>&1
 cr=$?;set -e
 echo "INTEGRATED_LAYER $check rc=$cr"
 cat /data/hardware-capture-bulk-integrated-guest1-$check-check.out
done
