from pathlib import Path
import subprocess,shutil
T=Path('/data/9os');R=Path('/data/desktop-bulk-integrated-root')
subprocess.run(['python3','/data/no-active-9os-vm.py'],check=True)
if R.exists():raise SystemExit('refuse existing fixture')
subprocess.run(['cp','-al','/data/desktop-bulk-a11y-root',str(R)],check=True)
for src,rel in [(T/'userland/alpine/desktop-overlay/usr/bin/alpine-plasma-probe','usr/bin/alpine-plasma-probe'),(T/'userland/alpine-root-x86_64/usr/bin/desktopa11y-dbus','usr/bin/desktopa11y-dbus')]:
 p=R/rel;p.unlink();shutil.copy2(src,p);p.chmod(0o755)
s=Path('/data/hardware-capture-bulk-a11y-guest1.sh').read_text().replace('bulk-a11y-guest1','bulk-integrated-guest1').replace('/data/desktop-bulk-a11y-root',str(R)).replace('/data/desktop-bulk-a11y.img','/data/desktop-bulk-integrated.img').replace('ALPINE_A11Y_DBUS_POST_READY_DIAGNOSTIC=1','ALPINE_A11Y_DBUS_VALIDATE=1')
p=Path('/data/hardware-capture-bulk-integrated-guest1.sh');p.write_text(s);p.chmod(0o755)
subprocess.run(['sh','-n',str(p)],check=True)
print('INTEGRATED_PROBE_PREPARED',flush=True)
