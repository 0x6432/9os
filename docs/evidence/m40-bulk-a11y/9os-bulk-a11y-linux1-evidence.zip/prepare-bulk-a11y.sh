#!/bin/bash
set -euo pipefail
export PATH=/data/tools/bin:$PATH
cd /data/9os
python3 /data/no-active-9os-vm.py
sha256sum -c /data/failure-phase-fixtures.sha256 >/dev/null
python3 /data/prepare-bulk-a11y.py
scripts/mkdisk.sh /data/desktop-bulk-a11y.img 3584 /data/desktop-bulk-a11y-root
sha256sum /data/desktop-bulk-a11y.img /data/desktop-bulk-a11y-root/usr/bin/{alpine-plasma-probe,desktopa11y,desktopa11y-dbus,konsole-key-trace,inputeventcapture,qt-key-observer-caller} /data/desktop-bulk-a11y-root/usr/lib/{lib9os-qt-key-observer.so,9os-tests/libqt-key-observer-mock.so} /data/hardware-capture-bulk-a11y-{linux1,guest1,guest2}.sh /data/9os/scripts/{qemu-type.py,qemu-ready-type.py,qemu-test.py,qt-key-observer-check.py,input-capture-check.py} /data/9os/build/x86_64-alpine/{kernel.elf,9os.iso,initramfs.cpio,limine.conf} /data/linux-tcg-desktop/bin/make /data/linux-tcg-desktop/physical-initramfs.cpio.gz /data/linux-input-oracle/root/boot/vmlinuz-virt /data/9os/tests/a11y-dbus-host/{terminal-dbus.c,mock-server.c,test-native.py} > /data/bulk-a11y-fixtures.sha256
printf 'BULK_A11Y_FIXTURES_READY\n'
