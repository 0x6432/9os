from pathlib import Path
import os,sys
found=[]
for p in Path('/proc').iterdir():
 if not p.name.isdigit() or int(p.name)==os.getpid():continue
 try:a=(p/'cmdline').read_bytes().split(b'\0')
 except OSError:continue
 if any(Path(x.decode(errors='replace')).name in ['qemu-system-x86_64','qemu-system-aarch64','qemu-system-riscv64']for x in a if x):found.append(p.name)
if found:print('Active VM PID(s):',','.join(found));sys.exit(1)
