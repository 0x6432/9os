from pathlib import Path
import subprocess,shutil
T=Path('/data/9os');R=Path('/data/desktop-bulk-a11y-root')
subprocess.run(['python3','/data/no-active-9os-vm.py'],check=True)
if R.exists():raise SystemExit('refuse existing root')
subprocess.run(['cp','-al','/data/desktop-failure-phase-root',str(R)],check=True)
p=R/'usr/bin/desktopa11y-dbus';shutil.copy2('/data/direct-a11y/terminal-dbus-target',p);p.chmod(0o755)
p=R/'usr/bin/alpine-plasma-probe';s=p.read_text()
def diagnostic(label):
 return f'''  echo {label}_BEGIN
  if timeout -k 2 -s TERM 8 desktopa11y-dbus "$client" > "$D/bulk-a11y.log" 2>&1;then bulk_rc=0;else bulk_rc=$?;fi
  cat "$D/bulk-a11y.log"
  echo "{label}_END rc=$bulk_rc"
'''
anchor='  echo KONSOLE_FAILURE_ONLY_A11Y_TRACE_BEGIN\n'
assert s.count(anchor)==1
s=s.replace(anchor,diagnostic('KONSOLE_FAILURE_ONLY_DBUS_BULK')+anchor)
anchor=' echo KONSOLE_FOCUSED_TERMINAL_READY\n'
assert s.count(anchor)==1
s=s.replace(anchor,anchor+' # PRIVATE independent real-Qt observation AFTER original readiness passes.\n if [ "${ALPINE_A11Y_DBUS_POST_READY_DIAGNOSTIC:-0}" = 1 ];then\n'+diagnostic('KONSOLE_POST_READY_DBUS_BULK')+' fi\n')
p.unlink();p.write_text(s);p.chmod(0o755)
for sample in ['linux1','guest1','guest2']:
 s=Path('/data/hardware-capture-failure-phase-'+sample+'.sh').read_text().replace('failure-phase-'+sample,'bulk-a11y-'+sample).replace('/data/desktop-failure-phase-root',str(R)).replace('/data/desktop-failure-phase.img','/data/desktop-bulk-a11y.img')
 s=s.replace('ALPINE_QT_KEY_TRACE=1 ','ALPINE_QT_KEY_TRACE=1 ALPINE_A11Y_DBUS_POST_READY_DIAGNOSTIC=1 ')
 p=Path('/data/hardware-capture-bulk-a11y-'+sample+'.sh');p.write_text(s);p.chmod(0o755)
print('Prepared independent bulk-query fixture; no normal gate/deadline changes, no kernel/Qt rebuild',flush=True)
