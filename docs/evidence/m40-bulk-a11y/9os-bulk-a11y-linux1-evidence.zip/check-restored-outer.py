#!/usr/bin/env python3
"""Read-only same-boot outer-wire sequence diagnostic, not GUI acceptance."""
from pathlib import Path
from importlib.machinery import SourceFileLoader
import re,json,sys
m=SourceFileLoader('capture_check','/data/9os/scripts/input-capture-check.py').load_module()
raw=Path(sys.argv[1]).read_text(errors='replace')
blocks=re.findall(r'^OUTER_KEYBOARD_TRACE_BEGIN\n(.*?)^OUTER_KEYBOARD_TRACE_END$',raw,re.M|re.S)
if not blocks:raise SystemExit('FAIL: no complete framed outer keyboard trace')
# Replayed diagnostic log may repeat one identical completed trace. Do not merge
# nonidentical blocks or use repeated output as independent observations.
if any(b!=blocks[0] for b in blocks):raise SystemExit('FAIL: ambiguous nonidentical trace blocks')
b=blocks[0]
if 'truncated=1' in b:raise SystemExit('FAIL: truncated trace')
key=re.compile(r'^WAYLAND_KEY_TRACE object=(\d+) event=key received_ns=(\d+) serial=(\d+) time_ms=(\d+) key=(\d+) state=(\d+)$')
rows=[];objects=set()
for line in b.splitlines():
 if 'event=key ' not in line:continue
 r=key.fullmatch(line)
 if not r:raise SystemExit('FAIL: malformed wire key record')
 obj,receipt,serial,stamp,code,state=map(int,r.groups());objects.add(obj);rows.append((code,state))
expected=[edge for frame in m.expected_frames(m.DEFAULT_TEXT)for edge in frame]
if len(objects)!=1 or rows!=expected:
 mismatch=next((i for i,(a,b)in enumerate(zip(rows,expected))if a!=b),min(len(rows),len(expected)))
 raise SystemExit('FAIL: wire key sequence mismatch at edge%d got%d expected%d objects%d'%(mismatch,len(rows),len(expected),len(objects)))
print(json.dumps({'key_edges':len(rows),'intended_taps':len(m.DEFAULT_TEXT),'identical_log_replays':len(blocks),'scope':'outer compositor -> KWin wire sequence only; not inner Qt delivery, timing or reliability proof'},sort_keys=True))
