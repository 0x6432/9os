#!/bin/bash
set -euo pipefail
export PATH=/data/tools/bin:$PATH
cd /data/9os
python3 /data/no-active-9os-vm.py
sha256sum -c /data/bulk-a11y-fixtures.sha256 >/dev/null
for sample in linux1 guest1 guest2;do
 python3 /data/no-active-9os-vm.py
 sha256sum -c /data/bulk-a11y-fixtures.sha256 >/dev/null
 echo "BULK_A11Y_START $sample $(date -u +%FT%TZ)"
 set +e
 if [ "$sample" = linux1 ];then PATH=/data/linux-tcg-desktop/bin:$PATH /data/hardware-capture-bulk-a11y-$sample.sh x86_64 > /data/hardware-capture-bulk-a11y-$sample.out 2>&1
 else /data/hardware-capture-bulk-a11y-$sample.sh x86_64 > /data/hardware-capture-bulk-a11y-$sample.out 2>&1;fi
 rc=$?;set -e
 echo "BULK_A11Y_END $sample rc=$rc $(date -u +%FT%TZ)"
 python3 /data/no-active-9os-vm.py
 sha256sum -c /data/bulk-a11y-fixtures.sha256 >/dev/null
 controls=1
 for check in raw outer qt;do
  case "$check" in raw) script=scripts/input-capture-check.py;;outer) script=/data/check-restored-outer.py;;qt) script=scripts/qt-key-observer-check.py;;esac
  set +e
  python3 "$script" $([ "$check" != qt ] || echo --require-no-autorepeat) build/test-hardware-capture-bulk-a11y-$sample-x86_64.log > /data/hardware-capture-bulk-a11y-$sample-$check-check.out 2>&1
  cr=$?;set -e
  echo "BULK_A11Y_LAYER $sample $check rc=$cr"
  cat /data/hardware-capture-bulk-a11y-$sample-$check-check.out
  [ "$cr" = 0 ] || controls=0
 done
 python3 /data/archive-bulk-a11y.py "$sample"
 if [ "$sample" = linux1 ];then
  [ "$controls" = 1 ] || { echo 'STOP invalid Linux event-layer control';exit 2; }
  python3 - <<'PY'
from pathlib import Path
import re
s=Path('/data/hardware-capture-bulk-a11y-linux1.out').read_text(errors='replace')
assert re.findall(r'^FAIL   .*$',s,re.M)==['FAIL   grep -q "^violations 0" /proc/lockdep']
assert re.findall(r'^\d+/\d+ passed$',s,re.M)==['17/18 passed']
assert re.search(r'^KONSOLE_POST_READY_DBUS_BULK_END rc=0$',s,re.M), 'independent helper must observe real signed-Linux Qt first'
pids=set(re.findall(r'^terminal-dbus: pid=(\d+) applications=1 models=1 visited=\d+ OBSERVED \(diagnostic only\)$',s,re.M))
import json
qt=json.loads(Path('/data/hardware-capture-bulk-a11y-linux1-qt-check.out').read_text())
assert pids=={str(qt['pid'])}, 'independent observed PID must match real Qt keyboard participant'

PY
 fi
done
