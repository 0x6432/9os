from pathlib import Path
import zipfile,sys,re
D=Path('/data');sample=sys.argv[1];files=set((D/'9os/build').glob(f'test-hardware-capture-bulk-a11y-{sample}-x86_64*'))
for pat in ['bulk-a11y-*','prepare-bulk-a11y.*','run-bulk-a11y.sh','archive-bulk-a11y.py','no-active-9os-vm.py','check-restored-outer.py',f'hardware-capture-bulk-a11y-{sample}*','direct-a11y-portable-*.log']:files.update(D.glob(pat))
files.update(p for p in(D/'direct-a11y').rglob('*')if p.is_file()and'__pycache__'not in p.parts)
files.add(D/'desktop-bulk-a11y-root/usr/bin/alpine-plasma-probe')
files.update(p for p in(D/'9os/tests/a11y-dbus-host').glob('*')if p.is_file())
out=D/f'9os-bulk-a11y-{sample}-evidence.zip'
with zipfile.ZipFile(out,'w',zipfile.ZIP_DEFLATED)as z:
 for p in sorted(files):
  if p.is_file():z.write(p,str(p.relative_to(D)))
s=(D/f'hardware-capture-bulk-a11y-{sample}.out').read_text(errors='replace')
for l in s.splitlines():
 if l.startswith(('KONSOLE_READINESS ','INPUT_CAPTURE_DONE ','terminal-dbus: ','KONSOLE_FAILURE_ONLY_DBUS_BULK_END','KONSOLE_POST_READY_DBUS_BULK_END'))or re.fullmatch(r'\d+/\d+ passed',l):print(l)
print('EVIDENCE_READY',out.name,out.stat().st_size,flush=True)
