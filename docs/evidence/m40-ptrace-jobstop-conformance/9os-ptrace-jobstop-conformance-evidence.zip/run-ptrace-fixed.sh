#!/bin/bash
set -euo pipefail
export PATH=/data/tools/bin:$PATH
cd /data/9os
# No overlaps with signed package assembly/extraction from restoration.
for i in $(seq 180);do grep -q RESTORED_SIGNED_X86_BASE_AND_DESKTOP /data/ptrace-baseline-controller.log && break;sleep 2;done
grep -q RESTORED_SIGNED_X86_BASE_AND_DESKTOP /data/ptrace-baseline-controller.log
make -j2 ARCH=x86_64 iso >/data/ptrace-fixed-build.log 2>&1
sha256sum build/x86_64/{kernel.elf,9os.iso,initramfs.cpio} userland/root-x86_64/bin/ptracestoptest >/data/ptrace-fixed-fixtures.sha256
set +e
PATH=/data/frozen-core/bin:$PATH python3 scripts/qemu-test.py x86_64 --timeout 65 --log build/ptrace-groupstop-fixed.log ptracetest 'timeout 35 ptracestoptest' 'su user -s /bin/sh -c "timeout 35 ptracestoptest"' 'grep -q "^violations 0" /proc/lockdep' >/data/ptrace-fixed.out 2>&1
rc=$?;set -e
echo "FIXED_QEMU_RC=$rc"
sha256sum -c /data/ptrace-fixed-fixtures.sha256
exit "$rc"
