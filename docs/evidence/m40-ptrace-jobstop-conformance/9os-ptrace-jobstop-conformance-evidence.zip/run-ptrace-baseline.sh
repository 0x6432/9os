#!/bin/bash
set -euo pipefail
export PATH=/data/tools/bin:$PATH
cd /data/9os
ARCH=x86_64 userland/mkroot.sh >/data/ptrace-baseline-mkroot.log 2>&1
make -j2 ARCH=x86_64 iso >/data/ptrace-baseline-build.log 2>&1
sha256sum build/x86_64/{kernel.elf,9os.iso,initramfs.cpio} userland/root-x86_64/bin/ptracestoptest >/data/ptrace-baseline-fixtures.sha256
set +e
PATH=/data/frozen-core/bin:$PATH python3 scripts/qemu-test.py x86_64 --timeout 65 --log build/ptrace-groupstop-baseline.log ptracetest 'timeout 35 ptracestoptest' 'su user -s /bin/sh -c "timeout 35 ptracestoptest"' >/data/ptrace-baseline.out 2>&1
rc=$?;set -e
echo "BASELINE_QEMU_RC=$rc"
sha256sum -c /data/ptrace-baseline-fixtures.sha256
cp build/x86_64/kernel.elf /data/ptrace-baseline-kernel.elf
cp userland/root-x86_64/bin/ptracestoptest /data/ptrace-baseline-test
# All heavy restoration below is AFTER the stopped baseline VM.
python3 userland/alpine/build.py --arch x86_64 >/data/restore-alpine-base.log 2>&1
python3 userland/alpine/build.py --arch x86_64 --profile desktop >/data/restore-alpine-desktop.log 2>&1
echo RESTORED_SIGNED_X86_BASE_AND_DESKTOP
