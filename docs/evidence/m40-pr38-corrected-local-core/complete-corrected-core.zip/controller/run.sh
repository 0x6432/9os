#!/bin/sh
set -eu
cd /data/9os
export PATH=/data/tools/bin:$PATH
ARCH=x86_64 userland/mkroot.sh
# mkroot refreshes in-tree tests, including unixpolltest and pollwakebench.
make -j2 ARCH=x86_64 iso
python3 - <<'PY'
from pathlib import Path
import hashlib,json
T=Path('/data/9os'); files=[T/'build/x86_64'/n for n in ['kernel.elf','9os.iso','initramfs.cpio']]
Path('/data/unix-wake-full-core-corrected/before.json').write_text(json.dumps({str(p):hashlib.sha256(p.read_bytes()).hexdigest()for p in files},indent=2))
PY
set +e
scripts/ci-tests.sh x86_64 --boot-timeout 300 > /data/unix-wake-full-core-corrected/tests.out 2>&1
rc=$?
set -e
echo "$rc" > /data/unix-wake-full-core-corrected/exit-code
python3 - <<'PY'
from pathlib import Path
import hashlib,json
D=Path('/data/unix-wake-full-core-corrected');b=json.loads((D/'before.json').read_text());a={p:hashlib.sha256(Path(p).read_bytes()).hexdigest()for p in b};(D/'after.json').write_text(json.dumps(a,indent=2));(D/'final-image-hashes-equal-initial').write_text(str(a==b)+'\n')
PY
exit "$rc"
