#!/usr/bin/env python3
"""Boot 9os in QEMU and run test commands on the serial console, expect-style.

usage: scripts/qemu-test.py ARCH [--smp N] [--boot-timeout S] [--timeout S] [--log FILE] CMD...
Each CMD runs as `CMD; echo __RC=$?` once the shell prompt is up; a CMD starting with "host:" runs on
the host instead (shell, must exit 0). With --net-test a host test server (scripts/net-host-server.py)
listens on @HP@ (the guest reaches it as 10.0.2.2:@HP@) and host port @FP@ forwards to guest TCP 8080 /
UDP 8081; both placeholders are substituted in every CMD. A test fails if its exit status
is non-zero or its output contains FAIL; the run fails on any kernel panic/oops.
Exit status: 0 if every test passed."""
import argparse, os, re, select, signal, subprocess, sys, time

ANSI = re.compile(rb'\x1b\[[0-9;?]*[a-zA-Z]|\r')
PROMPT = b'# '
PANIC = re.compile(rb'(?i)kernel panic|\bpanic:|page fault in kernel|\boops\b|unhandled exception|double fault')

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('arch')
    ap.add_argument('cmds', nargs='*')
    ap.add_argument('--smp', default='4')
    ap.add_argument('--sched', default='')
    ap.add_argument('--userland', choices=['source', 'alpine', 'alpine-desktop'], default='source')
    ap.add_argument('--memory', default=None, help='QEMU memory, e.g. 2048M for Alpine Qt')
    ap.add_argument('--boot-timeout', type=float, default=180)
    ap.add_argument('--timeout', type=float, default=240, help='per command')
    ap.add_argument('--log', default=None)
    ap.add_argument('--disk', action='append', default=[], help='raw image attached as virtio-blk (repeatable)')
    ap.add_argument('--cmdline', default=None, help='extra kernel command line')
    ap.add_argument('--net-test', action='store_true', help='host test server + port forwarding')
    a = ap.parse_intermixed_args()
    import socket as _s
    def free_port():
        k = _s.socket(); k.bind(('127.0.0.1', 0)); n = k.getsockname()[1]; k.close(); return n
    server = None
    net = '-netdev user,id=n0 -device virtio-net-pci,netdev=n0'
    if a.net_test:
        hp, fp = free_port(), free_port()
        server = subprocess.Popen([sys.executable, os.path.join(os.path.dirname(os.path.abspath(__file__)), 'net-host-server.py'), str(hp)],
                                  start_new_session=True)
        net = f'-netdev user,id=n0,hostfwd=tcp:127.0.0.1:{fp}-:8080,hostfwd=udp:127.0.0.1:{fp}-:8081 -device virtio-net-pci,netdev=n0'
        a.cmds = [c.replace('@HP@', str(hp)).replace('@FP@', str(fp)) for c in a.cmds]
    make = ['make', '-s', 'ARCH=' + a.arch, 'SMP=' + a.smp, 'run', 'QEMUFLAGS=-display none ' + os.environ.get('QEMU_EXTRA', '') +
            ''.join(f' -drive file={d},if=none,id=vd{k},format=raw -device virtio-blk-pci,drive=vd{k},serial=9os-disk{k}' for k, d in enumerate(a.disk))]
    make.insert(3, 'QEMU_NET=' + net)
    make.insert(3, 'USERLAND=' + a.userland)
    if a.memory: make.insert(3, 'QEMU_MEMORY=' + a.memory)
    if a.sched: make.insert(3, 'SCHED=' + a.sched)
    if a.cmdline: make.insert(3, 'CMDLINE=' + a.cmdline)
    p = subprocess.Popen(make, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                         start_new_session=True)
    log = open(a.log, 'wb') if a.log else None
    buf = bytearray()
    state = {'panic': False}

    def pump(deadline, pred):
        while time.time() < deadline:
            r, _, _ = select.select([p.stdout], [], [], 0.5)
            if r:
                d = os.read(p.stdout.fileno(), 65536)
                if not d: return False
                d = ANSI.sub(b'', d)
                buf.extend(d)
                if log: log.write(d); log.flush()
                sys.stdout.buffer.write(d); sys.stdout.flush()
                if PANIC.search(bytes(buf[-4096:])): state['panic'] = True; return False
                if pred(): return True
            elif p.poll() is not None:
                return False
        return False

    def send(s):
        # small chunks: a 16550 FIFO holds 16 bytes and the guest may be slow to drain it
        b = s.encode()
        for i in range(0, len(b), 8):
            p.stdin.write(b[i:i + 8]); p.stdin.flush()
            time.sleep(0.03)

    results = []
    # the boot console shows a prompt once the shell is up; poke it with newlines until we see one
    boot_deadline = time.time() + a.boot_timeout
    pump(min(boot_deadline, time.time() + 20), lambda: b'Welcome to 9os' in buf)
    pump(min(boot_deadline, time.time() + 5), lambda: buf.rstrip().endswith(b'login:'))
    ok = False
    # M31: the console runs getty+login; log in as root (no password) when asked
    at_login = lambda: buf.rstrip().endswith(b'login:')
    while not ok and time.time() < boot_deadline and not state['panic'] and p.poll() is None:
        if at_login(): send('root\n')
        else: send('\n')
        ok = pump(min(boot_deadline, time.time() + 10), lambda: buf.rstrip().endswith(b'#') or at_login())
        if ok and at_login(): ok = False
    if ok:
        pump(time.time() + 2, lambda: False)       # let the rest of the banner settle
    if not ok:
        print('\n*** boot failed (no shell prompt)%s' % (' - kernel panic' if state['panic'] else ''))
        results.append(('boot', False))
    else:
        results.append(('boot', True))
        for i, cmd in enumerate(a.cmds):
            if cmd.startswith('host:'):
                try:
                    hr = subprocess.run(cmd[5:], shell=True, timeout=a.timeout, capture_output=True)
                    out = hr.stdout + hr.stderr
                    passed = hr.returncode == 0
                except subprocess.TimeoutExpired:
                    out, passed = b'(timeout)', False
                sys.stdout.buffer.write(b'\n[host] ' + cmd[5:].encode() + b'\n' + out); sys.stdout.flush()
                if log: log.write(b'\n[host] ' + cmd[5:].encode() + b'\n' + out); log.flush()
                results.append((cmd, passed))
                continue
            mark = '__RC%d=' % i
            # wait for the prompt so the shell is reading (line editing in raw mode) before typing;
            # input typed while the previous command was still finishing could get lost
            pump(time.time() + 5, lambda: buf.rstrip().endswith(b'#'))
            start = len(buf)
            send('%s; echo %s$?\n' % (cmd, mark))
            rx = re.compile(re.escape(mark.encode()) + rb'(\d+)\n')
            got = pump(time.time() + a.timeout, lambda: rx.search(bytes(buf[start:])) is not None)
            out = bytes(buf[start:])
            m = rx.search(out)
            # skip the echoed command line itself (it contains the marker text but no digits+newline)
            body = out[out.find(b'\n') + 1:m.start()] if m else out
            passed = bool(m) and m.group(1) == b'0' and not re.search(rb'\bFAIL', body) and not state['panic']
            results.append((cmd, passed))
            if state['panic'] or p.poll() is not None: break
        if p.poll() is None:
            try:
                send('poweroff\n')
                pump(time.time() + 20, lambda: False)
            except BrokenPipeError:
                pass  # failed/exited VMs still get a useful test summary below
    try: os.killpg(p.pid, signal.SIGKILL)
    except ProcessLookupError: pass
    if server:
        try: os.killpg(server.pid, signal.SIGKILL)
        except ProcessLookupError: pass
    print('\n==== 9os test summary (%s, SMP=%s%s) ====' % (a.arch, a.smp, ', SCHED=' + a.sched if a.sched else ''))
    for name, passed in results: print('%-6s %s' % ('PASS' if passed else 'FAIL', name))
    if state['panic']: print('FAIL   kernel panic detected')
    bad = [n for n, ok_ in results if not ok_] or (['panic'] if state['panic'] else [])
    print('%d/%d passed' % (sum(1 for _, x in results if x), len(results)))
    sys.exit(1 if bad else 0)

main()
